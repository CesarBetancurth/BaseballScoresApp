package com.example.android.baseballscoresapp;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    /**
     * @Global Variables
     */
    int runsHome = 0;
    int hitsHome = 0;
    int errorsHome = 0;
    int pitchHome = 0;
    int runsVisitor = 0;
    int hitsVisitor = 0;
    int errorsVisitor = 0;
    int pitchVisitor = 0;
    int inning = 1;
    int ball = 0;
    int strike = 0;
    int out = 0;
    String half = "top";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayInningGame(inning);
        enableDisableButtonsScore(half);
    }

    /**
     * Increase the runs for Home by 1 run.
     */
    public void addOneRunHome(View v) {
        runsHome = runsHome + 1;
        displayRunsHome(runsHome);
        resetScoreGeneral(v);
    }

    /**
     * Increase the hits for Home by 1 hit.
     */
    public void addOneHitHome(View v) {
        hitsHome = hitsHome + 1;
        displayHitsHome(hitsHome);
        resetScoreGeneral(v);
    }

    /**
     * Increase the errors for Home by 1 error.
     */
    public void addOneErrorHome(View v) {
        errorsHome = errorsHome + 1;
        displayErrorsHome(errorsHome);
    }

    /**
     * Increase the pitches for Home by 1 pitch.
     */
    public void addOnePitchHome(View v) {
        pitchHome = pitchHome + 1;
        displayPitchGame(pitchHome);
    }

    /**
     * Increase the runs for Visitor by 1 run.
     */
    public void addOneRunVisitor(View v) {
        runsVisitor = runsVisitor + 1;
        displayRunsVisitor(runsVisitor);
        resetScoreGeneral(v);
    }

    /**
     * Increase the hits for Visitor by 1 hit.
     */
    public void addOneHitVisitor(View v) {
        hitsVisitor = hitsVisitor + 1;
        displayHitsVisitor(hitsVisitor);
        resetScoreGeneral(v);
    }

    /**
     * Increase the errors for Visitor by 1 error.
     */
    public void addOneErrorVisitor(View v) {
        errorsVisitor = errorsVisitor + 1;
        displayErrorsVisitor(errorsVisitor);
    }

    /**
     * Increase the pitches for Visitor by 1 pitch.
     */
    public void addOnePitchVisitor(View v) {
        pitchVisitor = pitchVisitor + 1;
        displayPitchGame(pitchVisitor);
    }

    /**
     * Increase the counter of innings by 1 inning.
     */
    public void addOneInning(View v) {
        inning = inning + 1;
        displayInningGame(inning);
    }

    /**
     * Increase the counter of balls by 1 ball.
     * When the count of the balls don't be less than 3, it call to resetScoreGeneral(Balls, Strikes, Outs).
     */
    public void addOneBall(View v) {
        if (ball < 3) {
            ball = ball + 1;
            displayBallGame(ball);
        } else {
            ball = ball + 1;
            displayBallGame(ball);
            resetScoreGeneral(v);
        }
    }

    /**
     * Increase the counter of strikes by 1 strike.
     * When the count of the strikes don't be less than 2, it call to addOneOut for increase outs.
     */
    public void addOneStrike(View v) {
        if (strike < 2) {
            strike = strike + 1;
            displayStrikeGame(strike);
        } else {
            strike = strike + 1;
            displayStrikeGame(strike);
            addOneOut(v);
        }
    }

    /**
     * Increase the counter of outs by 1 out.
     * Call to resetScoreGeneral(Balls, Strikes, Outs).
     */
    public void addOneOut(View v) {
        out = out + 1;
        displayOutGame(out);
        resetScoreGeneral(v);
    }

    /**
     * When the variable "half" its value is "top", it call the method to increase pitches for Home.
     * When the variable "half" its value is not "top" (bottom), it call the method to increase pitches for Visitor.
     */
    public void addOnePitch(View v) {
        if (half == "top") {
            addOnePitchHome(v);
        } else {
            addOnePitchVisitor(v);
        }
    }

    /**
     * Change the value of variable "half" and depending on the case display pitches for Visitor or Home.
     */
    public void changeHalf(View v) {
        if (half == "top") {
            half = "bottom";
            displayPitchGame(pitchVisitor);
            enableDisableButtonsScore(half);
        } else {
            half = "top";
            displayPitchGame(pitchHome);
            enableDisableButtonsScore(half);
            addOneInning(v);
        }
        displayHalvesGame(half);
    }

    /**
     * Get expression as figure of ordinal number for the innings.
     */
    public void getOrdinalText(View v) {
        int mod = 10;
        int result = inning % mod;
        String ordinalText = "";
        if (inning >= 11 && inning <= 13) {
            ordinalText = "th";
        } else {
            switch (result) {
                case 1:
                    ordinalText = "st";
                    break;
                case 2:
                    ordinalText = "nd";
                    break;
                case 3:
                    ordinalText = "rd";
                    break;
                default:
                    ordinalText = "th";
            }
        }
        displayOrdinalText(ordinalText);
    }

    /**
     * Reset value of variable for pitches depending on the value for variable "half"
     */
    public void resetPitches(View v) {
        if (half == "top") {
            pitchHome = 0;
            displayPitchGame(pitchHome);
        } else {
            pitchVisitor = 0;
            displayPitchGame(pitchVisitor);
        }
    }

    /**
     * Reset values of variables for counters of the balls, the strikes and the outs.
     */
    public void resetScoreGeneral(View v) {
        ball = 0;
        strike = 0;
        if (out == 3) {
            out = 0;
            changeHalf(v);
            getOrdinalText(v);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //do
                displayBallGame(ball);
                displayStrikeGame(strike);
                displayOutGame(out);
            }
        }, 150);//time in millisecond
    }

    /**
     * Reset all values of the variables for the Baseball Scoreboard.
     */
    public void resetScoreGame(View v) {
        runsHome = 0;
        hitsHome = 0;
        errorsHome = 0;
        pitchHome = 0;
        runsVisitor = 0;
        hitsVisitor = 0;
        errorsVisitor = 0;
        pitchVisitor = 0;
        inning = 1;
        ball = 0;
        strike = 0;
        out = 0;
        half = "top";
        displayRunsHome(runsHome);
        displayHitsHome(hitsHome);
        displayErrorsHome(errorsHome);
        displayRunsVisitor(runsVisitor);
        displayHitsVisitor(hitsVisitor);
        displayErrorsVisitor(errorsVisitor);
        displayInningGame(inning);
        displayBallGame(ball);
        displayStrikeGame(strike);
        displayOutGame(out);
        displayPitchGame(pitchHome);
        displayHalvesGame(half);
        displayOrdinalText("st");
        enableDisableButtonsScore(half);
    }

    /**
     * Display the count of runs for Home.
     */
    public void displayRunsHome(int runs) {
        TextView runsView = (TextView) findViewById(R.id.runsHome);
        runsView.setText(String.valueOf(runs));
    }

    /**
     * Display the count of hits for Home.
     */
    public void displayHitsHome(int hits) {
        TextView hitsView = (TextView) findViewById(R.id.hitsHome);
        hitsView.setText(String.valueOf(hits));
    }

    /**
     * Display the count of errors for Home.
     */
    public void displayErrorsHome(int errors) {
        TextView errorsView = (TextView) findViewById(R.id.errorsHome);
        errorsView.setText(String.valueOf(errors));
    }

    /**
     * Display the count of runs for Visitor
     */
    public void displayRunsVisitor(int runs) {
        TextView runsView = (TextView) findViewById(R.id.runsVisitor);
        runsView.setText(String.valueOf(runs));
    }

    /**
     * Display the count of hits for Visitor
     */
    public void displayHitsVisitor(int hits) {
        TextView hitsView = (TextView) findViewById(R.id.hitsVisitor);
        hitsView.setText(String.valueOf(hits));
    }

    /**
     * Display the count of errors for Visitor
     */
    public void displayErrorsVisitor(int errors) {
        TextView errorsView = (TextView) findViewById(R.id.errorsVisitor);
        errorsView.setText(String.valueOf(errors));
    }

    /**
     * Display the count of balls for the pitcher.
     */
    public void displayBallGame(int ball) {
        TextView ballsView = (TextView) findViewById(R.id.ball);
        ballsView.setText(String.valueOf(ball));
    }

    /**
     * Display the count of strikes for the pitcher.
     */
    public void displayStrikeGame(int strike) {
        TextView strikesView = (TextView) findViewById(R.id.strike);
        strikesView.setText(String.valueOf(strike));
    }

    /**
     * Display the count of outs in the inning.
     */
    public void displayOutGame(int out) {
        TextView outsView = (TextView) findViewById(R.id.out);
        outsView.setText(String.valueOf(out));
    }

    /**
     * Display the count of innings for the game.
     */
    public void displayInningGame(int inning) {
        TextView inningsView = (TextView) findViewById(R.id.inning);
        inningsView.setText(String.valueOf(inning));
        if (inning > 9) {
            inningsView.setTextColor(Color.RED);
        } else {
            inningsView.setTextColor(Color.BLACK);
        }
    }

    /**
     * Display the count of pitches for Visitor or Home.
     */
    public void displayPitchGame(int pitch) {
        TextView pitchesView = (TextView) findViewById(R.id.pitches);
        pitchesView.setText(String.valueOf(pitch));
    }

    /**
     * Display the halves values for the game.
     */
    public void displayHalvesGame(String half) {
        TextView halfView = (TextView) findViewById(R.id.half);
        halfView.setText(half);
    }

    /**
     * Display the expression as figure of ordinal number for the inning.
     */
    public void displayOrdinalText(String ordinal) {
        TextView ordinalView = (TextView) findViewById(R.id.ordinal);
        ordinalView.setText(ordinal);
        if (inning > 9) {
            ordinalView.setTextColor(Color.RED);
        } else {
            ordinalView.setTextColor(Color.BLACK);
        }
    }

    /**
     * Disable and enable the score buttons (runs and hits) depending on the value for variable "half"
     */
    public void enableDisableButtonsScore(String half) {
        Button runButtonVisitor = (Button) findViewById(R.id.runButtonVisitor);
        Button hitButtonVisitor = (Button) findViewById(R.id.hitButtonVisitor);
        Button errorButtonVisitor = (Button) findViewById(R.id.errorButtonVisitor);
        Button runButtonHome = (Button) findViewById(R.id.runButtonHome);
        Button hitButtonHome = (Button) findViewById(R.id.hitButtonHome);
        Button errorButtonHome = (Button) findViewById(R.id.errorButtonHome);
        if (half == "top") {
            runButtonVisitor.setEnabled(true);
            hitButtonVisitor.setEnabled(true);
            errorButtonVisitor.setEnabled(false);
            runButtonHome.setEnabled(false);
            hitButtonHome.setEnabled(false);
            errorButtonHome.setEnabled(true);
        } else {
            runButtonVisitor.setEnabled(false);
            hitButtonVisitor.setEnabled(false);
            errorButtonVisitor.setEnabled(true);
            runButtonHome.setEnabled(true);
            hitButtonHome.setEnabled(true);
            errorButtonHome.setEnabled(false);
        }
    }

}
